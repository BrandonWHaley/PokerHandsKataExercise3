﻿namespace PokerHands
{
    //The purpose of PokerHands is to determine which of two players wins a round based upon the value of the cards they hold. This exercise is intended to demonstrate to Manifest Solutions my current skill level and is step 3 of the 4 part process to get into bootcamp.
    //In writing this file I did not use any libraries or files taken from websites like GitHub as this is meant to be a demonstration of my skill level. Consequently if there are missing features that is because I do not have the necessary knowledge to include them.
    //Thank you -Brandon Haley
    public class PokerHands
    {
        public static void Main()  
        {
            HigherHandValue(BlackHand(), WhiteHand());
        }

        //Step 1 is to get input from both players to determine their card values and make sure they give some kind of input.
        public static int BlackHand()
        {
            //Get Blacks hand
            //Card 1
            Console.WriteLine("Black enter your first card.");
            String BCard1 = Console.ReadLine();
            while (BCard1 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                BCard1 = Console.ReadLine();
            }

            //Card 2
            Console.WriteLine("Enter your second card.");
            String BCard2 = Console.ReadLine();
            while (BCard2 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                BCard2 = Console.ReadLine();
            }

            //Card 3
            Console.WriteLine("Enter your third card.");
            String BCard3 = Console.ReadLine();
            while (BCard3 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                BCard3 = Console.ReadLine();
            }

            //Card 4
            Console.WriteLine("Enter your fourth card.");
            String BCard4 = Console.ReadLine();
            while (BCard4 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                BCard4 = Console.ReadLine();
            }

            //Card 5
            Console.WriteLine("Enter your fifth card.");
            String BCard5 = Console.ReadLine();
            while (BCard5 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                BCard5 = Console.ReadLine();
            }

            //Convert user input to int value
            int BHandValue = int.Parse(BCard1 + BCard2+ BCard3 + BCard4 + BCard5);


            Console.WriteLine("Black's Hand: " + BCard1 + " " + BCard2 + " " + BCard3 + " " + BCard4 + " " +  BCard5);
            Console.WriteLine("");

            return BHandValue;
        }
        public static int WhiteHand()
        {
            //Get Whites hand
            //Card 1
            Console.WriteLine("White enter your first card.");
            String WCard1 = Console.ReadLine();
            while (WCard1 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                WCard1 = Console.ReadLine();
            }

            //Card 2
            Console.WriteLine("Enter your second card.");
            String WCard2 = Console.ReadLine();
            while (WCard2 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                WCard2 = Console.ReadLine();
            }

            //Card 3
            Console.WriteLine("Enter your third card.");
            String WCard3 = Console.ReadLine();
            while (WCard3 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                WCard3 = Console.ReadLine();
            }

            //Card 4
            Console.WriteLine("Enter your fourth card.");
            String WCard4 = Console.ReadLine();
            while (WCard4 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                WCard4 = Console.ReadLine();
            }

            //Card 5
            Console.WriteLine("Enter your fifth card.");
            String WCard5 = Console.ReadLine();
            while (WCard5 == "")
            {
                Console.WriteLine("Please enter a valid card value!");
                WCard5 = Console.ReadLine();
            }

            //Convert user input to int value
            int WHandValue = int.Parse(WCard1 + WCard2 + WCard3 + WCard4 + WCard5);

            Console.WriteLine("White's Hand: " + WCard1 + " " + WCard2 + " " + WCard3 + " " + WCard4 + " " + WCard5);

            return WHandValue;
        }
        //Step 2 is to add up all the values of the cards and determine the winner.
        public static void HigherHandValue(int BHandValue, int WHandValue)
        {
            if (BHandValue > WHandValue)
            {
                Console.WriteLine("Black Wins!");
            }
            else if (BHandValue < WHandValue)
            {
                Console.WriteLine("White Wins!");
            }
        }
    }
}